export default function Footer(){
    return  (<footer><nav><ul>
            <li>Address</li>
            <li>Phone Number</li>
            <li>email</li>
        </ul></nav></footer>)
}