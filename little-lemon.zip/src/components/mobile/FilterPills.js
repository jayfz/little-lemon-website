export default function FilterPills() {
  return (
    <nav className="filter-pills">
      <h1>ORDER FOR DELIVERY!</h1>
      <ul>
        <li>Lunch</li>
        <li>Mains</li>
        <li>Desserts</li>
        <li>A la carte</li>
        <li>Specials</li>
      </ul>
    </nav>
  );
}
